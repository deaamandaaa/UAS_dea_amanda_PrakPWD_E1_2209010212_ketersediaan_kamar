<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('model_kamars', function (Blueprint $table) {
            $table->id()->unique();
            $table->foreign('kamar_id')->references('kamars')->on('nomor');
            $table->string('level_kamar');
            $table->string('fasilitas');
            $table->string('harga');
            $table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('model_kamars');
    }
};
