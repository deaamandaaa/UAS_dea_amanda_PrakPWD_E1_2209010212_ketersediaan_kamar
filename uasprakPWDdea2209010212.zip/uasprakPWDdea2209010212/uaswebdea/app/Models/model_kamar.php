<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class model_kamar extends Model
{
    protected $fillable = [
        'kamar-_id',
        'level_kamar',
        'fasilitas',
        'harga',
    ];
}
